﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FullPortManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class AddContainerSubtypeToVesselEvents : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
