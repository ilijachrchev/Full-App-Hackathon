﻿using FullPortManagementSystem.Data;
using FullPortManagementSystem.Models;
using FullPortManagementSystem.Services;
using Microsoft.AspNetCore.Mvc;

namespace FullPortManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VesselEventController : ControllerBase
    {
        private readonly PortDbContext _context;
        private readonly BerthAssignmentService _assignmentService;

        public VesselEventController(PortDbContext context)
        {
            _context = context;
            _assignmentService = new BerthAssignmentService();
        }

        // GET: api/vesselEvent
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var vessels = _context.VesselEvents.ToList();
                return Ok(vessels);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // POST: api/vesselEvent
        [HttpPost]
        public IActionResult Add(VesselEvent vessel)
        {
            try
            {
                var berthMap = new Dictionary<string, string>
                {
                    { "Tanker", "A" },
                    { "Container", "B" },
                    { "Bulk", "C" },
                    { "RoRo", "D" }
                };

                const int berthCap = 150;

                // Decide the intended berth
                if (!berthMap.TryGetValue(vessel.vessel_type, out var intendedBerthId))
                {
                    return BadRequest(new { error = "Invalid vessel type." });
                }

                // Calculate used space in this berth (by vessels that already Arrived)
                var used = _context.VesselEvents
                    .Where(v => v.berth_id == intendedBerthId && v.Status == "Arrived")
                    .Sum(v => v.vessel_size);

                if (used + vessel.vessel_size <= berthCap)
                {
                    // Assign directly
                    vessel.Status = "Arrived";
                    vessel.berth_id = intendedBerthId;
                    vessel.berth_type = vessel.vessel_type;
                }
                else
                {
                    // Not enough space → go to waiting
                    vessel.Status = "Waiting";
                    vessel.berth_id = null;
                    vessel.berth_type = vessel.vessel_type;
                }

                _context.VesselEvents.Add(vessel);
                _context.SaveChanges();

                return Ok(vessel);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/vesselEvent/berth-status
        [HttpGet("berth-status")]
        public IActionResult GetBerthStatus()
        {
            try
            {
                var vessels = _context.VesselEvents.ToList();
                var result = _assignmentService.GetBerthAssignments(vessels);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
